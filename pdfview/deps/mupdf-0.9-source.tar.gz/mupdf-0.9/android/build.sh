ndk-build && ant.bat install
